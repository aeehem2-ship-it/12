/* iXGAME Raven Protocol — verified offline cache.
 * This worker caches static site resources only. It does not modify PS4 storage.
 */
"use strict";
const CACHE_NAME = "ixgame-offline-v3-2026-11-16";
const CACHE_PREFIX = "ixgame-offline-";
const CORE_FILES = [
  "index.html",
  "offline.html",
  "offline.js",
  "offline.appcache",
  "assets/css/style.css",
  "assets/img/raven.svg",
  "assets/img/raven-protocol-hero.jpeg",
  "assets/js/app.js",
  "pages/docs.html",
  "pages/firmware.html",
  "pages/homebrew.html",
  "pages/jailbreak.html",
  "pages/payloads.html",
  "pages/tools.html",
  "pages/webkit.html",
  "payloads/manifest.json",
  "README.md",
  "LICENSE",
  "docs/FIRMWARE-NOTES.md",
  "jailbreak/IMG_7555.jpeg",
  "jailbreak/README.md",
  "jailbreak/LICENSE",
  "jailbreak/chain_lapse.js",
  "jailbreak/chain_poops.js",
  "jailbreak/core.js",
  "jailbreak/index.html",
  "jailbreak/int64.js",
  "jailbreak/logo_raw.png",
  "jailbreak/mem.js",
  "jailbreak/patches/1001.bin",
  "jailbreak/patches/1100.bin",
  "jailbreak/patches/1150.bin",
  "jailbreak/patches/1200.bin",
  "jailbreak/patches/1250.bin",
  "jailbreak/patches/1300.bin",
  "jailbreak/payload.bin",
  "jailbreak/ps4_offsets.js",
  "jailbreak/raven-watermark.png",
  "jailbreak/rpc_worker.js",
  "jailbreak/run_lapse.html",
  "jailbreak/run_poops.html",
  "jailbreak/ui.css"
];
const BASE = new URL("./", self.registration.scope);
const toURL = (path) => new URL(path, BASE).toString();

async function reportProgress(done, total, file) {
  const clients = await self.clients.matchAll({ includeUncontrolled: true, type: "window" });
  for (const client of clients) client.postMessage({ type: "IXGAME_CACHE_PROGRESS", done, total, file });
}

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    try {
      for (let i = 0; i < CORE_FILES.length; i++) {
        const path = CORE_FILES[i];
        const request = new Request(toURL(path), { method: "GET", cache: "reload", credentials: "same-origin" });
        const response = await fetch(request);
        if (!response || !response.ok || response.type === "opaque") {
          throw new Error("Precache failed for " + path + " (HTTP " + (response ? response.status : "no response") + ")");
        }
        await cache.put(request, response.clone());
        await reportProgress(i + 1, CORE_FILES.length, path);
      }
      const status = {
        version: CACHE_NAME,
        complete: true,
        total: CORE_FILES.length,
        cached: CORE_FILES.length,
        failed: [],
        completedAt: new Date().toISOString()
      };
      await cache.put(toURL("offline-status.json"), new Response(JSON.stringify(status), {
        headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
      }));
      await self.skipWaiting();
    } catch (error) {
      await caches.delete(CACHE_NAME);
      throw error;
    }
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request, { ignoreSearch: true });
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response && response.ok && response.type !== "opaque") {
        event.waitUntil(cache.put(request, response.clone()).catch(() => {}));
      }
      return response;
    } catch (error) {
      if (request.mode === "navigate") {
        return (await cache.match(toURL("offline.html"))) || (await cache.match(toURL("index.html"))) || Response.error();
      }
      return Response.error();
    }
  })());
});
