/* iXGAME offline cache manager. Presentation/cache layer only; jailbreak payload files are copied unchanged. */
const CACHE_NAME = "ixgame-full-offline-v2";
const CORE_FILES = [".gitignore", ".nojekyll", "LICENSE", "README.md", "assets/css/style.css", "assets/img/jailbreak-green.jpeg", "assets/img/jailbreak-red.jpeg", "assets/img/raven.svg", "assets/js/app.js", "assets/js/cache-gate.js", "docs/FIRMWARE-NOTES.md", "index.html", "jailbreak/.gitattributes", "jailbreak/.htaccess", "jailbreak/.nojekyll", "jailbreak/IMG_7555.jpeg", "jailbreak/LICENSE", "jailbreak/README.md", "jailbreak/cache.appcache", "jailbreak/chain_lapse.js", "jailbreak/chain_poops.js", "jailbreak/core.js", "jailbreak/index.html", "jailbreak/int64.js", "jailbreak/logo_raw.png", "jailbreak/mem.js", "jailbreak/patches/1001.bin", "jailbreak/patches/1100.bin", "jailbreak/patches/1150.bin", "jailbreak/patches/1200.bin", "jailbreak/patches/1250.bin", "jailbreak/patches/1300.bin", "jailbreak/payload.bin", "jailbreak/ps4_offsets.js", "jailbreak/raven-watermark.png", "jailbreak/rpc_worker.js", "jailbreak/run_lapse.html", "jailbreak/run_poops.html", "jailbreak/ui.css", "pages/docs.html", "pages/firmware.html", "pages/homebrew.html", "pages/jailbreak.html", "pages/payloads.html", "pages/tools.html", "pages/webkit.html", "payloads/manifest.json", "sw.js", "sw.js", "assets/js/cache-gate.js", "cache.appcache"];
const BASE = new URL("./", self.registration.scope);
const toURL = p => new URL(p, BASE).toString();
self.addEventListener("install", event => {
 event.waitUntil((async()=>{
  const cache=await caches.open(CACHE_NAME);
  await cache.addAll(CORE_FILES.map(toURL));
  await cache.put(toURL("ix-cache-ready.json"),new Response(JSON.stringify({ready:true,version:CACHE_NAME,total:CORE_FILES.length,completedAt:Date.now()}),{headers:{"Content-Type":"application/json"}}));
  await self.skipWaiting();
 })());
});
self.addEventListener("activate", event=>{event.waitUntil((async()=>{
 const keys=await caches.keys();
 await Promise.all(keys.filter(k=>k.startsWith("ixgame-full-offline-")&&k!==CACHE_NAME).map(k=>caches.delete(k)));
 await self.clients.claim();
})());});
self.addEventListener("fetch",event=>{
 const req=event.request,url=new URL(req.url);
 if(req.method!=="GET"||url.origin!==self.location.origin)return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE_NAME);
  const hit=await cache.match(req,{ignoreSearch:true}); if(hit)return hit;
  try{const res=await fetch(req);if(res&&res.ok)await cache.put(req,res.clone());return res;}
  catch(e){return req.mode==="navigate"?(await cache.match(toURL("offline.html")))||Response.error():Response.error();}
 })());
});
