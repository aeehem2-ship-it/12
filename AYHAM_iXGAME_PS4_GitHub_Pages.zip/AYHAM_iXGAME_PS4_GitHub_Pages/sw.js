/* iXGAME Offline Cache — static-site cache only; does not modify PS4 system storage. */
const CACHE_NAME = "ixgame-offline-v1-2026-11-15-r2";
const CORE_FILES = ['assets/css/style.css', 'assets/img/raven.svg', 'assets/js/app.js', 'index.html', 'jailbreak/IMG_7555.jpeg', 'jailbreak/chain_lapse.js', 'jailbreak/chain_poops.js', 'jailbreak/core.js', 'jailbreak/index.html', 'jailbreak/int64.js', 'jailbreak/logo_raw.png', 'jailbreak/mem.js', 'jailbreak/patches/1001.bin', 'jailbreak/patches/1100.bin', 'jailbreak/patches/1150.bin', 'jailbreak/patches/1200.bin', 'jailbreak/patches/1250.bin', 'jailbreak/patches/1300.bin', 'jailbreak/payload.bin', 'jailbreak/ps4_offsets.js', 'jailbreak/raven-watermark.png', 'jailbreak/rpc_worker.js', 'jailbreak/run_lapse.html', 'jailbreak/run_poops.html', 'jailbreak/ui.css', 'offline.html', 'offline.js', 'pages/docs.html', 'pages/firmware.html', 'pages/homebrew.html', 'pages/jailbreak.html', 'pages/payloads.html', 'pages/tools.html', 'pages/webkit.html', 'payloads/manifest.json'];
const BASE = new URL("./", self.registration.scope);
const toURL = (path) => new URL(path, BASE).toString();

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const urls = CORE_FILES.map(toURL);
    const results = await Promise.allSettled(urls.map((url) => cache.add(url)));
    const failed = results.map((r, i) => r.status === "rejected" ? CORE_FILES[i] : null).filter(Boolean);
    await cache.put(toURL("offline-status.json"), new Response(JSON.stringify({version:CACHE_NAME,total:urls.length,cached:urls.length-failed.length,failed}), {headers:{"Content-Type":"application/json"}}));
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith("ixgame-offline-") && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request, {ignoreSearch:true});
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response && response.ok) cache.put(request, response.clone());
      return response;
    } catch (error) {
      if (request.mode === "navigate") return (await cache.match(toURL("offline.html"))) || (await cache.match(toURL("index.html"))) || Response.error();
      return Response.error();
    }
  })());
});
