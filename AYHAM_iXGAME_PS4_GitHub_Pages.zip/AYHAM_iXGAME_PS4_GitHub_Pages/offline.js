(function () {
  "use strict";
  var script = document.currentScript;
  var root = new URL("./", script.src);
  var expectedVersion = "ixgame-offline-v4-2026-11-16";
  var html = document.documentElement;
  var panel = document.createElement("aside");
  panel.id = "ix-offline-panel";
  panel.innerHTML = '<span class="ix-offline-dot"></span><span class="ix-offline-label">CACHE: CHECKING</span><button type="button" class="ix-offline-update">RETRY</button>';
  var style = document.createElement("style");
  style.textContent = '#ix-offline-panel{position:fixed;z-index:99999;bottom:12px;right:12px;display:flex;align-items:center;gap:9px;padding:9px 11px;background:#10131a;border:1px solid #343b46;border-radius:4px;color:#dce1e8;font:11px Arial,sans-serif;box-shadow:0 5px 24px #0009}#ix-offline-panel .ix-offline-dot{width:7px;height:7px;border-radius:50%;background:#d9a441}#ix-offline-panel[data-state="ready"] .ix-offline-dot{background:#65c58a}#ix-offline-panel[data-state="failed"] .ix-offline-dot{background:#ed4059}#ix-offline-panel button{background:#651020;border:1px solid #a91d36;color:white;padding:6px 8px;border-radius:3px;font-size:10px}#ix-offline-panel button:disabled{opacity:.5}html.ix-cache-pending body{visibility:hidden}html.ix-cache-pending:before{content:attr(data-ix-cache-message);position:fixed;z-index:99998;inset:0;display:flex;align-items:center;justify-content:center;padding:28px;box-sizing:border-box;background:#090a0e;color:#f0f2f5;text-align:center;font:700 15px/1.7 Arial,sans-serif;visibility:visible;white-space:pre-wrap}html.ix-cache-failed:before{background:#090a0e;color:#ff9aaa}';
  document.head.appendChild(style);
  document.body.appendChild(panel);
  var label = panel.querySelector(".ix-offline-label");
  var button = panel.querySelector("button");
  var finished = false;
  var appCache = window.applicationCache;
  var serviceWorkerMode = !!(navigator.serviceWorker && window.fetch && window.Promise);
  var serviceWorkerFailed = false;
  function setLabel(text, stateName) { label.textContent = text; panel.setAttribute("data-state", stateName || "checking"); }
  function showReady(source) {
    if (finished) return;
    finished = true;
    html.classList.remove("ix-cache-pending", "ix-cache-failed");
    html.removeAttribute("data-ix-cache-message");
    setLabel("OFFLINE CACHE: VERIFIED", "ready");
    button.style.display = "none";
  }
  function showFailure(message) {
    if (finished) return;
    html.classList.add("ix-cache-pending", "ix-cache-failed");
    html.setAttribute("data-ix-cache-message", "iXGAME / CACHE ERROR\n" + message + "\nCheck your connection, then press RETRY.");
    setLabel("CACHE INCOMPLETE · RETRY", "failed");
    button.disabled = false;
    button.style.display = "inline-block";
  }
  function verifyWorker() {
    return fetch(new URL("offline-status.json", root).toString(), { cache: "no-store", credentials: "same-origin" }).then(function (response) {
      if (!response.ok) throw new Error("Cache status could not be read.");
      return response.json();
    }).then(function (status) {
      if (!status || status.version !== expectedVersion || status.complete !== true || status.cached !== status.total) {
        throw new Error("The required site files have not all been stored.");
      }
      showReady("service-worker");
    });
  }
  function waitForRegistration(registration) {
    var worker = registration.installing || registration.waiting;
    if (!worker) {
      if (registration.active) return Promise.resolve(registration);
      return Promise.reject(new Error("No active offline worker was created."));
    }
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(function () { cleanup(); reject(new Error("Saving the offline files took too long.")); }, 90000);
      function cleanup() { clearTimeout(timer); worker.removeEventListener("statechange", changed); }
      function changed() {
        if (worker.state === "activated") { cleanup(); resolve(registration); }
        else if (worker.state === "redundant") { cleanup(); reject(new Error("The offline worker installation failed.")); }
      }
      worker.addEventListener("statechange", changed);
      changed();
    });
  }
  function waitForController() {
    if (navigator.serviceWorker.controller) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(function () { cleanup(); reject(new Error("The offline worker did not take control of this page.")); }, 20000);
      function changed() { if (navigator.serviceWorker.controller) { cleanup(); resolve(); } }
      function cleanup() { clearTimeout(timer); navigator.serviceWorker.removeEventListener("controllerchange", changed); }
      navigator.serviceWorker.addEventListener("controllerchange", changed);
      changed();
    });
  }
  function useAppCacheFallback() {
    if (!appCache) return false;
    var ready = appCache.status === appCache.CACHED || appCache.status === appCache.IDLE;
    if (ready) { showReady("appcache"); return true; }
    return false;
  }
  if (appCache) {
    appCache.addEventListener("cached", function () { if (!serviceWorkerMode || serviceWorkerFailed) showReady("appcache"); });
    appCache.addEventListener("noupdate", function () { if (!serviceWorkerMode || serviceWorkerFailed) showReady("appcache"); });
    appCache.addEventListener("progress", function () { setLabel("SAVING SITE FILES…", "checking"); });
    appCache.addEventListener("error", function () { if (!("serviceWorker" in navigator)) showFailure("The browser could not save the offline files."); });
  }
  if (serviceWorkerMode) {
    setLabel("VERIFYING OFFLINE FILES…", "checking");
    navigator.serviceWorker.addEventListener("message", function (event) {
      var data = event.data || {};
      if (data.type === "IXGAME_CACHE_PROGRESS") setLabel("SAVING FILES " + data.done + " / " + data.total, "checking");
    });
    navigator.serviceWorker.register(new URL("sw.js", root).toString(), { scope: root.pathname }).then(function (registration) {
      return registration.update().catch(function () {}).then(function () { return waitForRegistration(registration); });
    }).then(waitForController).then(verifyWorker).catch(function (error) {
      if (!useAppCacheFallback()) showFailure(error && error.message ? error.message : "Offline cache verification failed.");
    });
  } else if (!useAppCacheFallback()) {
    showFailure("This browser does not provide a supported offline cache.");
  }
  button.addEventListener("click", function () {
    finished = false;
    button.disabled = true;
    setLabel("RETRYING CACHE…", "checking");
    html.classList.add("ix-cache-pending");
    html.classList.remove("ix-cache-failed");
    html.setAttribute("data-ix-cache-message", "iXGAME / RAVEN PROTOCOL\nChecking and saving offline files…");
    if (serviceWorkerMode) {
      serviceWorkerFailed = false;
      navigator.serviceWorker.register(new URL("sw.js", root).toString(), { scope: root.pathname }).then(function (registration) {
        return registration.update().catch(function () {}).then(function () { return waitForRegistration(registration); });
      }).then(waitForController).then(verifyWorker).catch(function (error) {
        button.disabled = false;
        serviceWorkerFailed = true;
        if (!useAppCacheFallback()) showFailure(error && error.message ? error.message : "Retry failed.");
      });
    } else if (!useAppCacheFallback()) {
      button.disabled = false;
      showFailure("Offline cache is unavailable in this browser.");
    }
  });
})();
