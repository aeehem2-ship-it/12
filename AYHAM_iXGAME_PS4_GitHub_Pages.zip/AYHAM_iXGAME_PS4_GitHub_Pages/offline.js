(function () {
  "use strict";
  var script = document.currentScript;
  var root = new URL("./", script.src);
  var panel = document.createElement("aside");
  panel.id = "ix-offline-panel";
  panel.innerHTML = '<span class="ix-offline-dot"></span><span class="ix-offline-label">OFFLINE CACHE: CHECKING</span><button type="button" class="ix-offline-update">UPDATE</button>';
  var style = document.createElement("style");
  style.textContent = '#ix-offline-panel{position:fixed;z-index:9999;bottom:12px;right:12px;display:flex;align-items:center;gap:9px;padding:9px 11px;background:#10131a;border:1px solid #343b46;border-radius:4px;color:#dce1e8;font:10px Arial,sans-serif;box-shadow:0 5px 24px #0009}#ix-offline-panel .ix-offline-dot{width:7px;height:7px;border-radius:50%;background:#d9a441;box-shadow:0 0 8px currentColor}#ix-offline-panel[data-state="ready"] .ix-offline-dot{background:#65c58a}#ix-offline-panel[data-state="offline"] .ix-offline-dot{background:#ed4059}#ix-offline-panel button{background:#651020;border:1px solid #a91d36;color:white;padding:6px 8px;border-radius:3px;font-size:9px}';
  document.head.appendChild(style);
  document.body.appendChild(panel);
  var label = panel.querySelector(".ix-offline-label");
  var button = panel.querySelector("button");
  function state(name, text) { panel.dataset.state = name; label.textContent = text; }
  function onlineState() { return navigator.onLine ? "ONLINE" : "OFFLINE"; }
  window.addEventListener("online", function(){ label.textContent = "CACHE READY · ONLINE"; });
  window.addEventListener("offline", function(){ state("offline", "OFFLINE · LOCAL COPY"); });

  var appCache = window.applicationCache;
  if (appCache) {
    appCache.addEventListener("cached", function(){ state("ready", "OFFLINE CACHE: READY"); });
    appCache.addEventListener("noupdate", function(){ state("ready", "OFFLINE CACHE: READY"); });
    appCache.addEventListener("updateready", function(){ state("ready", "UPDATE READY · RELOAD"); });
    appCache.addEventListener("error", function(){ state("offline", "CACHE FALLBACK · CHECK CONNECTION"); });
    appCache.addEventListener("progress", function(){ label.textContent = "SAVING SITE FILES…"; });
    if (appCache.status === appCache.CACHED || appCache.status === appCache.IDLE) state("ready", "OFFLINE CACHE: READY");
    else if (appCache.status === appCache.DOWNLOADING) label.textContent = "SAVING SITE FILES…";
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register(new URL("sw.js", root).toString(), {scope: root.pathname})
      .then(function(reg){
        return reg.update().catch(function(){}).then(function(){
          if (reg.active || navigator.serviceWorker.controller) state("ready", "OFFLINE CACHE: AVAILABLE");
          else label.textContent = "PREPARING OFFLINE CACHE…";
          navigator.serviceWorker.addEventListener("controllerchange", function(){ state("ready", "OFFLINE CACHE: READY"); });
        });
      })
      .catch(function(){ if (!appCache) state("offline", "OFFLINE CACHE: UNSUPPORTED"); });
  } else if (!appCache) {
    state("offline", "OFFLINE CACHE: UNSUPPORTED");
  }

  button.addEventListener("click", function(){
    button.disabled = true;
    label.textContent = "CHECKING FOR UPDATES…";
    var tasks = [];
    if ("serviceWorker" in navigator) tasks.push(navigator.serviceWorker.getRegistration(root.pathname).then(function(reg){ return reg ? reg.update() : navigator.serviceWorker.register(new URL("sw.js", root).toString(), {scope: root.pathname}); }));
    if (appCache && appCache.status !== appCache.UNCACHED) tasks.push(new Promise(function(resolve){ try { appCache.update(); resolve(); } catch(e) { resolve(); } }));
    Promise.allSettled(tasks).then(function(){
      label.textContent = "UPDATE CHECK COMPLETE · RELOAD IF ASKED";
      button.disabled = false;
    });
  });
})();
