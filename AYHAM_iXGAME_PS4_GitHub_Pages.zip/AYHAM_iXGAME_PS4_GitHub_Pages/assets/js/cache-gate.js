(function(){
'use strict';
var root=new URL('./',document.currentScript.src);
document.body.classList.add('ix-cache-locked');
var gate=document.createElement('section');gate.id='ix-cache-gate';gate.setAttribute('role','status');
gate.innerHTML='<div class="ix-sparks" aria-hidden="true"></div><div class="ix-gate-card"><h1 class="ix-gate-title">iXGAME OFFLINE SYSTEM</h1><p class="ix-gate-sub">يتم تجهيز نسخة الموقع المحلية. ستظهر الواجهة وأدواتها بعد اكتمال حفظ جميع الملفات المطلوبة.</p><div class="ix-cache-track"><div class="ix-cache-fill"></div></div><div class="ix-cache-state">جارٍ فحص دعم التخزين المحلي…</div><div class="ix-cache-error" hidden></div><button class="ix-cache-retry" hidden>إعادة المحاولة</button></div>';
document.body.appendChild(gate);
var state=gate.querySelector('.ix-cache-state'),fill=gate.querySelector('.ix-cache-fill'),err=gate.querySelector('.ix-cache-error'),retry=gate.querySelector('button');
var sparks=gate.querySelector('.ix-sparks');for(var i=0;i<24;i++){var s=document.createElement('i');s.className='ix-spark';s.style.setProperty('--x',(Math.random()*100)+'%');s.style.setProperty('--dur',(3+Math.random()*5)+'s');s.style.setProperty('--drift',((Math.random()*80)-40)+'px');s.style.animationDelay=(-Math.random()*8)+'s';sparks.appendChild(s);}
function unlock(){fill.style.width='100%';state.textContent='OFFLINE CACHE READY';setTimeout(function(){document.body.classList.remove('ix-cache-locked');gate.remove();},450);}
function fail(msg){state.textContent='CACHE REQUIRED';err.hidden=false;err.textContent=msg;retry.hidden=false;}
async function verifyCache(){
 if(!('caches' in window))throw new Error('هذا المتصفح لا يوفر واجهة Cache Storage اللازمة للتحقق من اكتمال التخزين.');
 var cache=await caches.open('ixgame-full-offline-v2');
 var response=await cache.match(new URL('ix-cache-ready.json',root).toString());
 if(!response)throw new Error('لم يكتمل حفظ ملفات الموقع بعد. أبقِ الاتصال بالإنترنت وحاول مجدداً.');
 var meta=await response.json();if(!meta.ready||!meta.total)throw new Error('تعذر التحقق من اكتمال ملفات الكاش.');
 var sw=await cache.match(new URL('sw.js',root).toString());if(!sw)throw new Error('ملف إدارة الكاش غير موجود في النسخة المحلية.');
 return meta;
}
async function start(){retry.hidden=true;err.hidden=true;fill.style.width='8%';state.textContent='جارٍ تحميل ملفات الموقع بالكامل…';
 try{
  if('serviceWorker' in navigator){
   var reg=await navigator.serviceWorker.register(new URL('sw.js',root).toString(),{scope:root.pathname});
   await reg.update().catch(function(){});
   if(!navigator.serviceWorker.controller){await new Promise(function(resolve,reject){var timer=setTimeout(function(){reject(new Error('لم يتم تفعيل عامل التخزين. أعد فتح الصفحة بعد السماح بتحميل الملفات.'));},18000);navigator.serviceWorker.addEventListener('controllerchange',function(){clearTimeout(timer);resolve();},{once:true});});}
   fill.style.width='72%';state.textContent='جارٍ التحقق من جميع الملفات المحفوظة…';
   var meta=await verifyCache();fill.style.width='100%';state.textContent='تم حفظ '+meta.total+' ملفاً';unlock();return;
  }
  var app=window.applicationCache;
  if(app && (app.status===app.CACHED||app.status===app.IDLE)){unlock();return;}
  fail('لا يدعم هذا المتصفح آلية التخزين المطلوبة أو لم يكتمل تنزيل الكاش. لن يتم إظهار الموقع أو السماح ببدء التعديل.');
 }catch(e){fail(e&&e.message?e.message:'حدث خطأ أثناء تحميل الكاش.');}
}
retry.addEventListener('click',start);
window.addEventListener('online',function(){if(document.body.classList.contains('ix-cache-locked'))start();});
start();
})();
