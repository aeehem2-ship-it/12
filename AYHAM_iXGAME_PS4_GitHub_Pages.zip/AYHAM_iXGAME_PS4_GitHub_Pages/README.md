# AYHAM × iXGAME — Raven Protocol

A static PS4 research, homebrew and jailbreak portal designed for GitHub Pages.

## Included
- Original iXGAME frontend and raven identity.
- Dedicated jailbreak page with firmware notes and a direct launcher.
- Supplied RawGame4 Lapse / Poops exploit chain stored in `/jailbreak/`.
- Original upstream notices and license files preserved in `/jailbreak/LICENSE`.
- GitHub Pages Actions deployment workflow.

## Deploy
1. Create a GitHub repository and upload the contents of this folder to its root.
2. Open **Settings → Pages** and select **GitHub Actions**.
3. Push to `main` or `master`; the included workflow deploys the site.

## Firmware support — source-grounded
The supplied RawGame4 README lists 10.01 (Lapse, not hardware-tested), 11.00, 11.50, 12.00 and 12.02 (Lapse), and 12.50, 12.52 and 13.00 (Poops). It reports hardware testing for all listed versions except 10.01. These are upstream claims, not independent iXGAME tests.

The supplied exploit package does **not** include a 9.00 chain. The site therefore labels 9.00 as not included instead of presenting a fake launch route. It also does not claim support for every intermediate version between 12.00 and 13.00.

## Licensing and attribution
The original iXGAME website files retain the root MIT license. The exploit package retains its own `jailbreak/LICENSE`, README, and third-party component notices. In particular, the RawGame4 license says the MIT grant does not cover SLOPKIT components, GoldHEN `payload.bin`, or the kernel patch blobs. Keep these notices intact when redistributing.

## Safety
Kernel exploits can crash or reboot a console and may cause data loss. Use only on hardware you own or are authorized to modify. No game content or piracy functionality is included.

## Offline mode
- The site now includes a root-level offline manifest and a Service Worker cache for its local pages, styles, scripts, artwork and bundled jailbreak resources.
- Open the deployed site on the PS4 while online and allow the first cache pass to finish; the small **OFFLINE CACHE** panel reports the browser-side cache state.
- Use **UPDATE** while online after publishing a new build, then reload if prompted.
- Browser storage can be cleared by the console, and browser support varies. The PS4 browser must be tested on the exact firmware; this project does not claim offline compatibility until that test is completed.
- Offline caching stores website files only. It does not install firmware changes or make a jailbreak persistent across a console reboot.
